#ifndef RL_FPRINTF_H
# define RL_FPRINTF_H

# include <stdio.h>

void rl_fprintf(FILE *f, char *fmt, ...);

#endif /* !RL_FPRINTF_H */
